import type { Config } from "tailwindcss";

export default {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        void: "#060606",                          // identical to the frame background
        ink: "rgb(237 232 224 / <alpha-value>)",  // warm off-white; use /90 and /55
        rose: "#C9A05C",                          // the single accent
      },
      fontFamily: {
        display: ["var(--font-display)", "Georgia", "serif"],
        sans: ["var(--font-sans)", "system-ui", "sans-serif"],
      },
      letterSpacing: { label: "0.28em" },
      transitionTimingFunction: { maison: "cubic-bezier(0.22, 0.61, 0.36, 1)" },
    },
  },
  plugins: [],
} satisfies Config;
