import { NextResponse } from "next/server";

// Stub: wire to your CRM / email provider.
export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  if (!body?.name || !body?.email) return NextResponse.json({ ok: false }, { status: 400 });
  console.log("[appointment request]", body);
  return NextResponse.json({ ok: true });
}
