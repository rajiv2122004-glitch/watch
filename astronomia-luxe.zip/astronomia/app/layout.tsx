import type { Metadata, Viewport } from "next";
import { Fraunces, Hanken_Grotesk } from "next/font/google";
import "./globals.css";

const display = Fraunces({
  subsets: ["latin"], variable: "--font-display", display: "swap",
  axes: ["opsz", "SOFT"], weight: "variable", style: ["normal", "italic"],
});
const sans = Hanken_Grotesk({ subsets: ["latin"], variable: "--font-sans", display: "swap", weight: ["300", "400", "500"] });

export const metadata: Metadata = {
  title: "Astronomia Luxe — Time, laid bare.",
  description: "A skeleton perpetual calendar in 18k rose gold. 407 components, assembled by one watchmaker.",
};
export const viewport: Viewport = { themeColor: "#060606", colorScheme: "dark" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${display.variable} ${sans.variable}`}>
      <body>{children}</body>
    </html>
  );
}
