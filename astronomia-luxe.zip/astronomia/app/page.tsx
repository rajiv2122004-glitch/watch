import Nav from "@/components/Nav";
import Hero from "@/components/Hero";
import Specs from "@/components/Specs";
import MacroBand from "@/components/MacroBand";
import Craft from "@/components/Craft";
import Reserve from "@/components/Reserve";
import Footer from "@/components/Footer";

export default function Page() {
  return (
    <main>
      <Nav />
      <Hero />
      <Specs />
      <MacroBand />
      <Craft />
      <Reserve />
      <Footer />
    </main>
  );
}
