#!/usr/bin/env python3
"""
Normalises the raw frame export for the hero scrub.

  python3 scripts/prepare-frames.py path/to/frames-dir

 - removes the generator's corner sparkle (cv2 inpaint, diamond mask)
 - lifts black to exactly #060606 so frame and page background match
 - writes public/frames/f-0001.webp ..., public/hero-exploded.webp (reduced motion)
 - writes macro crops used by the parallax band
"""
import sys, glob, os
import cv2, numpy as np

src = sys.argv[1] if len(sys.argv) > 1 else "frames"
out = "public/frames"
files = sorted(glob.glob(os.path.join(src, "frame-*.jpg")))
assert files, f"no frames in {src}"

H, W = cv2.imread(files[0]).shape[:2]
cx, cy, r = int(W * 0.90625), int(H * 0.8333), 34      # sparkle centre (1160,600 @1280x720)
yy, xx = np.mgrid[0:H, 0:W]
mask = ((abs(xx - cx) + abs(yy - cy)) <= r).astype(np.uint8) * 255

BG = 6.0
def clean(img):
    img = cv2.inpaint(img, mask, 5, cv2.INPAINT_TELEA)
    f = img.astype(np.float32)
    f = BG + f * ((255.0 - BG) / 255.0)                  # black -> #060606
    return np.clip(f, 0, 255).astype(np.uint8)

def crop(img, name, x, y, w, h, out_w):
    c = img[y:y+h, x:x+w]
    c = cv2.resize(c, (out_w, int(out_w * h / w)), interpolation=cv2.INTER_LANCZOS4)
    blur = cv2.GaussianBlur(c, (0, 0), 2.0)
    c = cv2.addWeighted(c, 1.5, blur, -0.5, 0)
    cv2.imwrite(f"public/macro/{name}.jpg", c, [cv2.IMWRITE_JPEG_QUALITY, 88])

for i, p in enumerate(files, 1):
    img = clean(cv2.imread(p))
    cv2.imwrite(f"{out}/f-{i:04d}.webp", img, [cv2.IMWRITE_WEBP_QUALITY, 82])
    if i == len(files) - 40:                               # settled exploded state
        cv2.imwrite("public/hero-exploded.webp", img, [cv2.IMWRITE_WEBP_QUALITY, 90])
        crop(img, "movement", 470, 190, 440, 250, 2000)    # upscaled; swap for real macro photography
        crop(img, "case", 830, 150, 330, 300, 1400)
print(f"{len(files)} frames written")
