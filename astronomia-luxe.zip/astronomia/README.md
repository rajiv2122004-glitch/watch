# Astronomia Luxe

    npm install
    npm run dev

- Hero engine: `lib/frameSequence.ts` (progressive fetch, off-thread `createImageBitmap` decode, windowed memory) and `components/Hero.tsx` (canvas draw, scroll-ranged overlays, reduced-motion fallback).
- Re-process frames: `python3 scripts/prepare-frames.py <dir-of-frame-*.jpg>` (needs opencv-python). Inpaints the corner sparkle and lifts black to exactly #060606.
- Tune overlay timing in `ScrubHero` (`from`/`to`), canvas fit in `draw()`, pin length via `h-[450vh]`.
- `public/macro/*.jpg` are crops of the hero frames: swap in real macro photography.
- `app/api/appointment/route.ts` is a stub; connect it to your CRM / mail provider.
