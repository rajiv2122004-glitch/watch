import Reveal from "./Reveal";

export default function Craft() {
  return (
    <section className="mx-auto max-w-[1400px] px-6 py-32 md:px-12 md:py-48">
      <Reveal>
        <p className="label mb-8">Craftsmanship</p>
        <h2 className="display max-w-4xl text-[2.2rem] leading-[1.08] text-ink/90 md:text-[4rem]">
          Four hundred and seven parts, <span className="italic text-ink/55">and one pair of hands.</span>
        </h2>
      </Reveal>

      <div className="mt-20 grid gap-12 md:mt-32 md:grid-cols-2 md:gap-24">
        <Reveal>
          <p className="display text-[1.35rem] leading-[1.45] text-ink/90 md:text-[1.6rem]">
            In most ateliers a watch passes through twenty hands. Here it passes through two:
            the watchmaker’s, and, at the very end, yours.
          </p>
          <div className="hairline my-10" />
          <dl className="grid grid-cols-3 gap-6">
            {[["407", "components"], ["62", "jewels"], ["11", "weeks, one bench"]].map(([n, l]) => (
              <div key={l}>
                <dt className="display text-[2rem] text-rose">{n}</dt>
                <dd className="label mt-3 !leading-relaxed">{l}</dd>
              </div>
            ))}
          </dl>
        </Reveal>

        <Reveal delay={0.1} className="space-y-7 text-[15px] leading-[1.85] text-ink/55 md:columns-1">
          <p>
            Every bridge is cut, then finished by hand: anglage along each edge, a bevel polished with
            pegwood and diamantine until it holds a single, unbroken line of light. A single bridge can
            take a full day. The movement has eleven.
          </p>
          <p>
            The twin balance wheels are poised against one another and regulated in six positions over
            weeks, not hours. The rubies are set into gold chatons one at a time, and the screws are
            heat-blued in a tray of brass filings, watched by eye, never by timer.
          </p>
          <p>
            When the last screw is turned, the watchmaker signs the bridge. The watch is then dismantled
            once more, cleaned, and reassembled, so that the first time it is wound is by the person who
            will wear it.
          </p>
        </Reveal>
      </div>
    </section>
  );
}
