export default function Footer() {
  return (
    <footer className="border-t border-ink/[0.09]">
      <div className="mx-auto flex max-w-[1400px] flex-col gap-6 px-6 py-10 md:flex-row md:items-center md:justify-between md:px-12">
        <span className="label !tracking-[0.36em] !text-ink/90">Astronomia Luxe</span>
        <p className="label">© 2026 · Genève · Made by hand</p>
        <ul className="flex gap-8">
          {["Privacy", "Contact"].map((l) => (
            <li key={l}><a href="#" className="label transition-colors duration-[900ms] ease-maison hover:!text-ink/90">{l}</a></li>
          ))}
        </ul>
      </div>
    </footer>
  );
}
