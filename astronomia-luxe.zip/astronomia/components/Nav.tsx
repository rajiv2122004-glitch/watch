"use client";
import { useEffect, useState } from "react";
import { useMotionValueEvent, useScroll } from "framer-motion";

const links = [
  { href: "#watch", label: "The Watch" },
  { href: "#movement", label: "Movement" },
  { href: "#reserve", label: "Reserve" },
];

export default function Nav() {
  const { scrollY } = useScroll();
  const [solid, setSolid] = useState(false);
  useMotionValueEvent(scrollY, "change", (y) => setSolid(y > 48));
  useEffect(() => setSolid(window.scrollY > 48), []);

  return (
    <header
      className="fixed inset-x-0 top-0 z-50 transition-[background-color,border-color,backdrop-filter] duration-[1000ms] ease-maison"
      style={{
        backgroundColor: solid ? "rgb(6 6 6 / 0.78)" : "rgb(6 6 6 / 0)",
        borderBottom: `1px solid ${solid ? "rgb(237 232 224 / 0.12)" : "transparent"}`,
        backdropFilter: solid ? "blur(6px)" : "none",
      }}
    >
      <nav className="mx-auto flex h-14 max-w-[1600px] items-center justify-between px-6 md:h-16 md:px-12">
        <a href="#watch" className="label !text-ink/90 !tracking-[0.36em]">Astronomia Luxe</a>
        <ul className="flex gap-5 md:gap-10">
          {links.map((l) => (
            <li key={l.href}>
              <a href={l.href} className="label transition-colors duration-[900ms] ease-maison hover:!text-ink/90">
                {l.label}
              </a>
            </li>
          ))}
        </ul>
      </nav>
    </header>
  );
}
