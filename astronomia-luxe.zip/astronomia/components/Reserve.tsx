"use client";
import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import Reveal, { EASE } from "./Reveal";

type State = "idle" | "sending" | "sent" | "error";

export default function Reserve() {
  const [state, setState] = useState<State>("idle");

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setState("sending");
    const data = Object.fromEntries(new FormData(e.currentTarget));
    try {
      const r = await fetch("/api/appointment", {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data),
      });
      setState(r.ok ? "sent" : "error");
    } catch { setState("error"); }
  }

  return (
    <section id="reserve" className="border-t border-ink/[0.09]">
      <div className="mx-auto grid max-w-[1400px] gap-16 px-6 py-32 md:grid-cols-12 md:gap-8 md:px-12 md:py-48">
        <Reveal className="md:col-span-5">
          <p className="label mb-8">Reserve</p>
          <h2 className="display text-[2.4rem] leading-[1.06] text-ink/90 md:text-[3.8rem]">
            By private appointment.
          </h2>
          <p className="mt-8 max-w-sm text-[15px] leading-relaxed text-ink/55">
            Astronomia Luxe is made in an edition of thirty-six a year. We receive collectors by
            appointment only, at the atelier or at a place of your choosing.
          </p>
        </Reveal>

        <div className="md:col-span-6 md:col-start-7">
          <AnimatePresence mode="wait">
            {state !== "sent" ? (
              <motion.form
                key="form" onSubmit={onSubmit} exit={{ opacity: 0 }}
                transition={{ duration: 0.8, ease: EASE }} className="space-y-9"
              >
                <Field label="Full name"><input name="name" required autoComplete="name" className="field" /></Field>
                <Field label="Email"><input name="email" type="email" required autoComplete="email" className="field" /></Field>
                <div className="grid gap-9 md:grid-cols-2">
                  <Field label="Country"><input name="country" autoComplete="country-name" className="field" /></Field>
                  <Field label="Appointment">
                    <select name="venue" className="field" defaultValue="atelier">
                      <option value="atelier">At the atelier, Geneva</option>
                      <option value="residence">At my residence</option>
                      <option value="video">Private video viewing</option>
                    </select>
                  </Field>
                </div>
                <Field label="A note (optional)"><textarea name="note" rows={2} className="field resize-none" /></Field>
                <div className="flex items-center gap-8 pt-4">
                  <button type="submit" disabled={state === "sending"} className="cta disabled:opacity-50">
                    {state === "sending" ? "Sending" : "Request an appointment"}
                    <span aria-hidden className="h-px w-8 bg-rose/60" />
                  </button>
                  {state === "error" && <p className="text-sm text-ink/55">Something went wrong. Please try again.</p>}
                </div>
              </motion.form>
            ) : (
              <motion.div
                key="sent" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 1.1, ease: EASE }}
              >
                <p className="display text-[1.8rem] leading-snug text-ink/90 md:text-[2.2rem]">Thank you.</p>
                <p className="mt-5 max-w-sm text-[15px] leading-relaxed text-ink/55">
                  A member of the maison will write to you personally within two working days.
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="label mb-1 block">{label}</span>
      {children}
    </label>
  );
}
