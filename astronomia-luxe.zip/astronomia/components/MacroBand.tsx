"use client";
import { useRef } from "react";
import { motion, useReducedMotion, useScroll, useTransform } from "framer-motion";
import Reveal from "./Reveal";

export default function MacroBand() {
  const ref = useRef<HTMLElement>(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], ["-9%", "9%"]);

  return (
    <section ref={ref} className="relative h-[80svh] min-h-[480px] overflow-hidden bg-void" aria-label="Macro photograph of the movement">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <motion.img
        src="/macro/movement.jpg" alt="Twin balance wheels and ruby jewels inside the Astronomia Luxe movement"
        style={{ y: reduce ? 0 : y }}
        className="absolute -top-[12%] left-0 h-[124%] w-full object-cover opacity-90"
      />
      {/* seat the photograph into the page background */}
      <div className="pointer-events-none absolute inset-x-0 top-0 h-[18svh] bg-gradient-to-b from-void to-transparent" />
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-[24svh] bg-gradient-to-t from-void to-transparent" />
      <Reveal className="absolute bottom-10 left-6 md:bottom-14 md:left-12">
        <p className="label"><span className="text-rose">Fig. 2</span>&ensp;Twin balance wheels, rubies in gold chatons</p>
      </Reveal>
    </section>
  );
}
