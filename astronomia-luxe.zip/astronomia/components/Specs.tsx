import Reveal from "./Reveal";

const sheet = [
  { n: "I", title: "Movement", rows: [
    ["Calibre", "AL-407, self-winding"],
    ["Components", "407"],
    ["Jewels", "62, ruby"],
    ["Frequency", "28,800 vph (4 Hz)"],
    ["Regulation", "Twin balance wheels, averaged"],
    ["Power reserve", "72 hours"],
    ["Finishing", "Anglage, Côtes de Genève, hand-bevelled bridges"],
  ]},
  { n: "II", title: "Complications", rows: [
    ["Calendar", "Perpetual — date, day, month, leap year"],
    ["Moonphase", "Hand-engraved; one day’s error in 122 years"],
    ["Dial", "Skeletonised, blackened"],
  ]},
  { n: "III", title: "Case", rows: [
    ["Material", "18k 5N rose gold"],
    ["Diameter", "41.0 mm"],
    ["Height", "12.4 mm"],
    ["Crystal", "Sapphire, domed, anti-reflective both faces"],
    ["Caseback", "Sapphire, exhibition"],
    ["Strap", "Hand-stitched alligator, chocolate; rose gold pin buckle"],
  ]},
  { n: "IV", title: "Water resistance", rows: [
    ["Rating", "30 metres / 3 bar"],
    ["Note", "Splash-proof. Not intended for swimming."],
  ]},
];

export default function Specs() {
  return (
    <section id="movement" className="mx-auto grid max-w-[1400px] gap-16 px-6 py-32 md:grid-cols-12 md:gap-8 md:px-12 md:py-48">
      <div className="md:col-span-4">
        <Reveal>
          <p className="label mb-6">Specification</p>
          <h2 className="display text-[2.2rem] leading-[1.08] text-ink/90 md:text-[3.2rem]">
            Calibre <span className="text-rose">AL-407</span>
          </h2>
          <p className="mt-6 max-w-xs text-[15px] leading-relaxed text-ink/55">
            Designed, finished and regulated in a single atelier. Every watch is numbered and
            signed on the bridge by the watchmaker who built it.
          </p>
        </Reveal>
      </div>

      <div className="md:col-span-7 md:col-start-6">
        {sheet.map((g, gi) => (
          <Reveal key={g.n} delay={gi * 0.05} className="mb-16 last:mb-0">
            <div className="flex items-baseline gap-5 border-t border-rose/40 pt-5">
              <span className="display text-sm italic text-rose">{g.n}.</span>
              <h3 className="label !text-ink/90">{g.title}</h3>
            </div>
            <dl>
              {g.rows.map(([k, v]) => (
                <div key={k} className="grid grid-cols-[8.5rem_1fr] gap-4 border-b border-ink/[0.09] py-4 md:grid-cols-[11rem_1fr]">
                  <dt className="label self-center">{k}</dt>
                  <dd className="text-[15px] leading-snug text-ink/90">{v}</dd>
                </div>
              ))}
            </dl>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
