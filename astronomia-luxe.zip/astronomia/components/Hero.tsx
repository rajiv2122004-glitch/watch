"use client";
import { useEffect, useRef } from "react";
import { MotionValue, motion, useReducedMotion, useScroll, useTransform } from "framer-motion";
import { FrameSequence } from "@/lib/frameSequence";
import Reveal from "./Reveal";

/* ------------------------------------------------------------------ */
/*  Copy                                                               */
/* ------------------------------------------------------------------ */
const Cta = () => (
  <a href="#reserve" className="cta pointer-events-auto">
    Reserve yours <span aria-hidden className="h-px w-8 bg-rose/60" />
  </a>
);

const Dial = () => (
  <>
    <p className="label mb-5"><span className="text-rose">01</span>&ensp;The Dial</p>
    <h2 className="display text-[1.7rem] leading-[1.12] text-ink/90 md:text-[2.5rem]">
      A perpetual calendar with nothing to hide.
    </h2>
    <p className="mt-4 text-[13px] leading-relaxed text-ink/55 md:mt-6 md:text-[15px]">
      A skeletonised dial in blackened sapphire-grey, cut away to the date ring and a hand-engraved
      moonphase that drifts one day in 122 years.
    </p>
  </>
);
const Movement = () => (
  <>
    <p className="label mb-5"><span className="text-rose">02</span>&ensp;The Movement</p>
    <h2 className="display text-[1.7rem] leading-[1.12] text-ink/90 md:text-[2.5rem]">
      407 components. Zero shortcuts.
    </h2>
    <p className="mt-4 text-[13px] leading-relaxed text-ink/55 md:mt-6 md:text-[15px]">
      Twin balance wheels averaging out error. Sixty-two ruby jewels, set by hand. Bridges anglé,
      bevelled and polished until the light no longer knows where the edge is.
    </p>
  </>
);
const Maker = () => (
  <>
    <p className="label mb-5"><span className="text-rose">03</span>&ensp;The Maker</p>
    <h2 className="display text-[1.7rem] leading-[1.12] text-ink/90 md:text-[2.5rem]">
      Assembled by one watchmaker, start to finish.
    </h2>
    <div className="mt-7 md:mt-9"><Cta /></div>
  </>
);

/* ------------------------------------------------------------------ */
/*  Canvas stage                                                       */
/* ------------------------------------------------------------------ */
const N = 240, SW = 1280, SH = 720, BG = "#060606";
const smooth = (x: number) => { x = Math.min(1, Math.max(0, x)); return x * x * (3 - 2 * x); };
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

function CanvasStage({ progress }: { progress: MotionValue<number> }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const barRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current!;
    const ctx = canvas.getContext("2d", { alpha: false })!;
    let vw = 0, vh = 0, dpr = 1, portrait = false;
    let target = progress.get() * (N - 1), current = target, raf = 0;

    const seq = new FrameSequence({
      count: N,
      url: (i) => `/frames/f-${String(i + 1).padStart(4, "0")}.webp`,
      resizeWidth: window.innerWidth < 768 ? 960 : SW,
      radius: 10,
      onUpdate: () => schedule(),
      onProgress: (l, t) => {
        const bar = barRef.current; if (!bar) return;
        bar.style.transform = `scaleX(${l / t})`;
        if (l === t) bar.style.opacity = "0";
      },
    });

    // soft edges, painted in frame space, so the sequence has no visible rectangle
    const E = 110;
    const edge = (x0: number, y0: number, x1: number, y1: number) => {
      const g = ctx.createLinearGradient(x0, y0, x1, y1);
      g.addColorStop(0, "rgba(6,6,6,1)"); g.addColorStop(1, "rgba(6,6,6,0)");
      return g;
    };

    function draw(f: number) {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.globalAlpha = 1;
      ctx.fillStyle = BG;
      ctx.fillRect(0, 0, vw, vh);
      const i0 = Math.min(N - 1, Math.floor(f)), i1 = Math.min(N - 1, i0 + 1), t = f - i0;
      const a = seq.nearest(i0);
      if (!a) return;

      // On portrait screens the whole sequence rotates a quarter-turn as it explodes,
      // so the exploded axis runs vertically.
      const p = f / (N - 1);
      const k = portrait ? smooth((p - 0.06) / 0.42) : 0;
      const th = (k * Math.PI) / 2;
      const c = Math.abs(Math.cos(th)), s = Math.abs(Math.sin(th));
      const bw = SW * c + SH * s, bh = SW * s + SH * c;
      let scale: number, cy: number;
      if (portrait) {
        const fit = Math.min(vw / bw, (vh * 0.64) / bh);
        scale = lerp((vw * 0.7) / 330, fit, k);          // start tight on the watch
        cy = vh * lerp(0.4, 0.37, k);
      } else {
        scale = Math.min(vw / SW, vh / SH) * 0.96;
        cy = vh / 2;
      }
      ctx.translate(vw / 2, cy);
      ctx.rotate(th);
      ctx.scale(scale, scale);
      ctx.translate(-SW / 2, -SH / 2);

      ctx.drawImage(a, 0, 0, SW, SH);
      if (t > 0.002 && i1 !== i0) {
        const b = seq.nearest(i1);
        if (b && b !== a) { ctx.globalAlpha = t; ctx.drawImage(b, 0, 0, SW, SH); ctx.globalAlpha = 1; }
      }
      ctx.fillStyle = edge(0, 0, 0, E);       ctx.fillRect(0, 0, SW, E);
      ctx.fillStyle = edge(0, SH, 0, SH - E); ctx.fillRect(0, SH - E, SW, E);
      ctx.fillStyle = edge(0, 0, E, 0);       ctx.fillRect(0, 0, E, SH);
      ctx.fillStyle = edge(SW, 0, SW - E, 0); ctx.fillRect(SW - E, 0, E, SH);
    }

    function tick() {
      raf = 0;
      const d = target - current;
      current = Math.abs(d) < 0.005 ? target : current + d * 0.2;   // light inertia, no snapping
      seq.setFocus(current);
      draw(current);
      if (current !== target) raf = requestAnimationFrame(tick);
    }
    function schedule() { if (!raf) raf = requestAnimationFrame(tick); }

    const resize = () => {
      const r = canvas.getBoundingClientRect();
      vw = r.width; vh = r.height; dpr = Math.min(window.devicePixelRatio || 1, 2);
      portrait = vw < 768 || vh > vw * 1.1;
      canvas.width = Math.round(vw * dpr); canvas.height = Math.round(vh * dpr);
      schedule();
    };
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);
    resize();

    const unsub = progress.on("change", (v) => { target = v * (N - 1); schedule(); });
    seq.start();

    return () => { unsub(); ro.disconnect(); cancelAnimationFrame(raf); seq.destroy(); };
  }, [progress]);

  return (
    <>
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" aria-hidden />
      <div
        ref={barRef}
        className="absolute inset-x-0 bottom-0 h-px origin-left bg-rose/50 transition-opacity duration-[1400ms]"
        style={{ transform: "scaleX(0)" }}
      />
    </>
  );
}

/* ------------------------------------------------------------------ */
/*  Scroll-ranged overlay                                              */
/* ------------------------------------------------------------------ */
function Overlay({
  progress, from, to, first, hold, className, children,
}: {
  progress: MotionValue<number>; from: number; to: number; first?: boolean; hold?: boolean;
  className: string; children: React.ReactNode;
}) {
  const f = 0.05;
  const xs = first ? [0, to - f, to] : [from, from + f, to - f, to];
  const os = first ? [1, 1, 0] : [0, 1, 1, hold ? 1 : 0];
  const ys = first ? [0, 0, -14] : [16, 0, 0, hold ? 0 : -14];
  const opacity = useTransform(progress, xs, os);
  const y = useTransform(progress, xs, ys);
  const pointerEvents = useTransform(opacity, (o) => (o > 0.4 ? "auto" : "none"));
  return (
    <motion.div style={{ opacity, y, pointerEvents }} className={`absolute z-10 ${className}`}>
      {children}
    </motion.div>
  );
}

const side = "inset-x-6 bottom-[6svh] text-center md:inset-x-auto md:bottom-[9svh] md:max-w-[26rem]";

function ScrubHero() {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end end"] });
  const p = scrollYProgress;

  return (
    // 450vh section − 100vh viewport = 350vh of pinned scroll
    <section ref={ref} id="watch" className="relative h-[450vh] bg-void">
      <div className="sticky top-0 h-[100svh] overflow-hidden bg-void">
        <CanvasStage progress={p} />

        <Overlay progress={p} from={0} to={0.2} first className="inset-x-6 bottom-[8svh] text-center md:bottom-[9svh]">
          <h1 className="display text-[2.6rem] leading-none text-ink/90 md:text-[5rem]">Astronomia Luxe</h1>
          <p className="display mt-3 text-[1.25rem] italic text-ink/55 md:mt-5 md:text-[1.75rem]">Time, laid bare.</p>
          <p className="label mt-8 hidden md:block">Scroll</p>
        </Overlay>

        <Overlay progress={p} from={0.2} to={0.45} className={`${side} md:left-[6vw] md:text-left`}><Dial /></Overlay>
        <Overlay progress={p} from={0.45} to={0.75} className={`${side} md:right-[6vw] md:text-right`}><Movement /></Overlay>
        <Overlay progress={p} from={0.75} to={1} hold className={`${side} md:left-[6vw] md:text-left`}><Maker /></Overlay>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/*  prefers-reduced-motion: one still, simple fades                    */
/* ------------------------------------------------------------------ */
function StaticHero() {
  return (
    <section id="watch" className="bg-void pt-24 md:pt-28">
      <motion.div
        initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1.2 }}
        className="px-6 text-center"
      >
        <h1 className="display text-[2.6rem] leading-none text-ink/90 md:text-[5rem]">Astronomia Luxe</h1>
        <p className="display mt-4 text-[1.25rem] italic text-ink/55 md:text-[1.75rem]">Time, laid bare.</p>
      </motion.div>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src="/hero-exploded.webp" width={1280} height={720}
        alt="Astronomia Luxe exploded into its components: crystal, bezel, dial, movement, case and strap"
        className="mx-auto mt-6 w-full max-w-[1400px]"
      />
      <div className="mx-auto grid max-w-3xl gap-20 px-6 pb-28 pt-8 md:gap-28">
        <Reveal><Dial /></Reveal>
        <Reveal><Movement /></Reveal>
        <Reveal><Maker /></Reveal>
      </div>
    </section>
  );
}

export default function Hero() {
  const reduce = useReducedMotion();
  return reduce ? <StaticHero /> : <ScrubHero />;
}
