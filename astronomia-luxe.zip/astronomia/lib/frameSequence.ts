/**
 * Progressive, windowed frame sequence.
 *
 *  - Encoded frames (blobs, ~50 KB each) are fetched in priority order:
 *    frame 1 → every KEY_EVERY-th frame → everything else.
 *  - Decoding uses createImageBitmap(), which decodes off the main thread.
 *  - Only keyframes + a window around the playhead stay decoded, so memory stays
 *    flat (~100–180 MB) instead of 240 × 3.7 MB.
 *  - nearest() always returns *something* drawable once any keyframe is in, so a
 *    fast scrub falls back to the closest decoded frame instead of stalling.
 */
export type SequenceOptions = {
  count: number;
  url: (i: number) => string;        // 0-based index → URL
  keyEvery?: number;
  radius?: number;                   // decoded window either side of the playhead
  resizeWidth?: number;              // decode at display size to save memory
  onUpdate?: () => void;
  onProgress?: (loaded: number, total: number) => void;
};

export class FrameSequence {
  private blobs: (Blob | undefined)[];
  private bitmaps: (ImageBitmap | undefined)[];
  private decoding = new Set<number>();
  private focus = 0;
  private dead = false;
  private loaded = 0;
  private keyEvery: number;
  private radius: number;

  constructor(private o: SequenceOptions) {
    this.blobs = new Array(o.count);
    this.bitmaps = new Array(o.count);
    this.keyEvery = o.keyEvery ?? 12;
    this.radius = o.radius ?? 10;
  }

  start() {
    const { count } = this.o;
    const order: number[] = [0];
    for (let i = this.keyEvery; i < count; i += this.keyEvery) order.push(i);
    order.push(count - 1);
    for (let i = 0; i < count; i++) if (!order.includes(i)) order.push(i);
    const queue = [...new Set(order)];
    const worker = async () => {
      while (!this.dead && queue.length) {
        // pull frames nearest the playhead first once the keyframes are in
        const idx = this.nextIndex(queue);
        const i = queue.splice(idx, 1)[0];
        try {
          const res = await fetch(this.o.url(i));
          this.blobs[i] = await res.blob();
        } catch { continue; }
        this.loaded++;
        this.o.onProgress?.(this.loaded, count);
        if (this.wanted(i)) await this.decode(i);
      }
    };
    // first lane grabs frame 0 immediately; five more join in parallel
    worker();
    for (let k = 0; k < 5; k++) setTimeout(worker, 30 * k);
  }

  private nextIndex(queue: number[]) {
    // keyframes were queued first; after them, prefer frames closest to the playhead
    const keysLeft = queue.findIndex((q) => q % this.keyEvery !== 0 && q !== this.o.count - 1);
    if (keysLeft > 0) return 0;
    let best = 0, d = Infinity;
    for (let k = 0; k < queue.length; k++) {
      const dd = Math.abs(queue[k] - this.focus);
      if (dd < d) { d = dd; best = k; }
    }
    return best;
  }

  private isKey(i: number) { return i % this.keyEvery === 0 || i === this.o.count - 1; }
  private wanted(i: number) { return this.isKey(i) || Math.abs(i - this.focus) <= this.radius; }

  private async decode(i: number) {
    const blob = this.blobs[i];
    if (!blob || this.bitmaps[i] || this.decoding.has(i) || this.dead) return;
    this.decoding.add(i);
    try {
      const bmp = await createImageBitmap(
        blob,
        this.o.resizeWidth ? { resizeWidth: this.o.resizeWidth, resizeQuality: "medium" } : undefined
      );
      if (this.dead || !this.wanted(i)) bmp.close();
      else this.bitmaps[i] = bmp;
    } catch { /* ignore */ }
    this.decoding.delete(i);
    this.o.onUpdate?.();
  }

  /** Call whenever the playhead moves; keeps the decoded window centred on it. */
  setFocus(f: number) {
    const i = Math.round(f);
    if (i === this.focus) return;
    this.focus = i;
    const lo = i - this.radius, hi = i + this.radius;
    for (let k = Math.max(0, lo); k <= Math.min(this.o.count - 1, hi); k++) this.decode(k);
    for (let k = 0; k < this.o.count; k++) {
      const b = this.bitmaps[k];
      if (b && !this.isKey(k) && (k < lo || k > hi)) { b.close(); this.bitmaps[k] = undefined; }
    }
  }

  /** Nearest decoded bitmap to index i (searching outward). */
  nearest(i: number): ImageBitmap | undefined {
    const n = this.o.count;
    i = Math.max(0, Math.min(n - 1, Math.round(i)));
    for (let d = 0; d < n; d++) {
      const a = this.bitmaps[i - d]; if (a) return a;
      const b = this.bitmaps[i + d]; if (b) return b;
    }
  }

  exact(i: number) { return this.bitmaps[i]; }

  destroy() {
    this.dead = true;
    this.bitmaps.forEach((b) => b?.close());
    this.bitmaps = [];
  }
}
